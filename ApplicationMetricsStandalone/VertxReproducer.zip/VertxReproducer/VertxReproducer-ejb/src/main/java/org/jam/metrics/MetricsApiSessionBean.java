/*
 * Copyleft 2017 Red Hat, Inc. and/or its affiliates
 * and other contributors as indicated by the @author tags.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jam.metrics;

import io.vertx.core.Vertx;

import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import java.util.concurrent.CountDownLatch;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;

/**
 *
 * @author Panagiotis Sotiropoulos
 */
public class MetricsApiSessionBean {
    private Vertx vertx;
    private Router router;
    private String url = "http://localhost:8180/apm";
    private HttpServer server = null;
    private HttpClient client;

    public MetricsApiSessionBean() {
        vertx = Vertx.vertx();
        router = Router.router(vertx);

        router.route(HttpMethod.POST, "/apm").handler(this::handleApmData);

        server = vertx.createHttpServer().requestHandler(router::accept).listen(8180);
    }

    public void countMethod() throws Exception {
        try {

                client = HttpClientBuilder.create().build();
                HttpPost post = new HttpPost(url);
                HttpResponse response = client.execute(post);
                System.out.println("\nSending 'POST' request to URL : " + url);
                System.out.println("Post parameters : " + post.getEntity());
                System.out.println("Response Code : "
                        + response.getStatusLine().getStatusCode());
                CountDownLatch latch = new CountDownLatch(1);
                server.close(v -> latch.countDown());
                latch.await();
        } catch (Exception ex) {
            try {
                System.out.println("11111111333333331111111111");
                CountDownLatch latch = new CountDownLatch(1);
                server.close(v -> latch.countDown());
                latch.await();
                ex.printStackTrace();
            } catch (InterruptedException ex1) {
                ex1.printStackTrace();
            }
        }

    }
    
    public void handleApmData(RoutingContext routingContext) {
        routingContext.request().bodyHandler(buf -> {
            try {
                JsonObject apmRoot = buf.toJsonObject();
            }catch(Exception ex) {
                System.out.println("11111111333333331111111111");
                ex.printStackTrace();
            }
        });

    }

}
